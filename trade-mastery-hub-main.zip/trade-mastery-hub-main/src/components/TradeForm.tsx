import { useState } from "react";
import { Stock } from "@/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useProgressStore } from "@/store/progressStore";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface TradeFormProps {
  stock: Stock;
  onTrade: () => void;
}

export function TradeForm({ stock, onTrade }: TradeFormProps) {
  const [tradeType, setTradeType] = useState<'BUY' | 'SELL'>('BUY');
  const [quantity, setQuantity] = useState('1');
  const [stopLoss, setStopLoss] = useState('');
  const [targetPrice, setTargetPrice] = useState('');
  
  const { progress, updateBalance, addToPortfolio, removeFromPortfolio, addTrade } = useProgressStore();
  
  const qty = parseInt(quantity) || 0;
  const totalValue = qty * stock.price;
  const portfolioItem = progress.portfolio.find(p => p.symbol === stock.symbol);
  const maxSellQty = portfolioItem?.quantity || 0;
  
  const canBuy = tradeType === 'BUY' && qty > 0 && totalValue <= progress.virtualBalance;
  const canSell = tradeType === 'SELL' && qty > 0 && qty <= maxSellQty;
  const canTrade = canBuy || canSell;

  const handleTrade = () => {
    if (!canTrade) return;
    
    // Simulate slight price slippage
    const slippage = (Math.random() - 0.5) * 0.002;
    const executionPrice = stock.price * (1 + slippage);
    const executionValue = qty * executionPrice;
    
    if (tradeType === 'BUY') {
      updateBalance(-executionValue);
      addToPortfolio(stock.symbol, stock.name, qty, executionPrice);
      toast.success(`Bought ${qty} shares of ${stock.symbol} at ₹${executionPrice.toFixed(2)}`);
    } else {
      updateBalance(executionValue);
      removeFromPortfolio(stock.symbol, qty, executionPrice);
      const profit = portfolioItem ? (executionPrice - portfolioItem.avgPrice) * qty : 0;
      toast.success(`Sold ${qty} shares of ${stock.symbol}. ${profit >= 0 ? 'Profit' : 'Loss'}: ₹${Math.abs(profit).toFixed(2)}`);
    }
    
    addTrade({
      id: Date.now().toString(),
      symbol: stock.symbol,
      type: tradeType,
      quantity: qty,
      price: executionPrice,
      timestamp: new Date(),
      stopLoss: stopLoss ? parseFloat(stopLoss) : undefined,
      targetPrice: targetPrice ? parseFloat(targetPrice) : undefined
    });
    
    setQuantity('1');
    setStopLoss('');
    setTargetPrice('');
    onTrade();
  };

  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <div className="flex gap-2 mb-4">
        <Button
          variant={tradeType === 'BUY' ? 'default' : 'outline'}
          onClick={() => setTradeType('BUY')}
          className={cn("flex-1", tradeType === 'BUY' && "bg-primary")}
        >
          Buy
        </Button>
        <Button
          variant={tradeType === 'SELL' ? 'default' : 'outline'}
          onClick={() => setTradeType('SELL')}
          className={cn("flex-1", tradeType === 'SELL' && "bg-destructive hover:bg-destructive/90")}
        >
          Sell
        </Button>
      </div>
      
      <div className="space-y-4">
        <div>
          <Label htmlFor="quantity">Quantity</Label>
          <Input
            id="quantity"
            type="number"
            min="1"
            max={tradeType === 'SELL' ? maxSellQty : undefined}
            value={quantity}
            onChange={(e) => setQuantity(e.target.value)}
            className="mt-1"
          />
          {tradeType === 'SELL' && (
            <p className="text-xs text-muted-foreground mt-1">
              Available: {maxSellQty} shares
            </p>
          )}
        </div>
        
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="stopLoss">Stop Loss</Label>
            <Input
              id="stopLoss"
              type="number"
              placeholder={`< ₹${stock.price.toFixed(0)}`}
              value={stopLoss}
              onChange={(e) => setStopLoss(e.target.value)}
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="target">Target Price</Label>
            <Input
              id="target"
              type="number"
              placeholder={`> ₹${stock.price.toFixed(0)}`}
              value={targetPrice}
              onChange={(e) => setTargetPrice(e.target.value)}
              className="mt-1"
            />
          </div>
        </div>
        
        <div className="p-3 rounded-lg bg-secondary/50">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Price per share</span>
            <span>₹{stock.price.toLocaleString()}</span>
          </div>
          <div className="flex justify-between text-sm mt-1">
            <span className="text-muted-foreground">Quantity</span>
            <span>{qty}</span>
          </div>
          <div className="border-t border-border my-2" />
          <div className="flex justify-between font-semibold">
            <span>Total</span>
            <span>₹{totalValue.toLocaleString()}</span>
          </div>
        </div>
        
        <Button 
          onClick={handleTrade} 
          disabled={!canTrade}
          className={cn(
            "w-full",
            tradeType === 'SELL' && "bg-destructive hover:bg-destructive/90"
          )}
          size="lg"
        >
          {tradeType === 'BUY' ? 'Buy' : 'Sell'} {stock.symbol}
        </Button>
        
        {tradeType === 'BUY' && totalValue > progress.virtualBalance && (
          <p className="text-xs text-destructive text-center">
            Insufficient balance. Available: ₹{progress.virtualBalance.toLocaleString()}
          </p>
        )}
      </div>
    </div>
  );
}
