import { useProgressStore } from "@/store/progressStore";
import { cn } from "@/lib/utils";
import { TrendingUp, TrendingDown } from "lucide-react";

export function Portfolio() {
  const { progress } = useProgressStore();
  
  const totalValue = progress.portfolio.reduce(
    (sum, item) => sum + item.quantity * item.currentPrice,
    0
  );
  
  const totalPnL = progress.portfolio.reduce(
    (sum, item) => sum + (item.currentPrice - item.avgPrice) * item.quantity,
    0
  );

  if (progress.portfolio.length === 0) {
    return (
      <div className="rounded-xl border border-border bg-card p-6 text-center">
        <p className="text-muted-foreground">No holdings yet. Start trading!</p>
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-border bg-card overflow-hidden">
      <div className="p-4 border-b border-border bg-secondary/30">
        <div className="flex justify-between items-center">
          <div>
            <p className="text-sm text-muted-foreground">Portfolio Value</p>
            <p className="text-2xl font-bold">₹{totalValue.toLocaleString()}</p>
          </div>
          <div className={cn(
            "text-right",
            totalPnL >= 0 ? "text-primary" : "text-destructive"
          )}>
            <p className="text-sm">Total P&L</p>
            <p className="text-lg font-semibold flex items-center gap-1 justify-end">
              {totalPnL >= 0 ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
              {totalPnL >= 0 ? "+" : ""}₹{totalPnL.toFixed(2)}
            </p>
          </div>
        </div>
      </div>
      
      <div className="divide-y divide-border">
        {progress.portfolio.map((item) => {
          const pnl = (item.currentPrice - item.avgPrice) * item.quantity;
          const pnlPercent = ((item.currentPrice - item.avgPrice) / item.avgPrice) * 100;
          const isPositive = pnl >= 0;
          
          return (
            <div key={item.symbol} className="p-4 hover:bg-secondary/20 transition-colors">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-semibold">{item.symbol}</p>
                  <p className="text-sm text-muted-foreground">{item.name}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {item.quantity} shares @ ₹{item.avgPrice.toFixed(2)} avg
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-semibold">
                    ₹{(item.quantity * item.currentPrice).toLocaleString()}
                  </p>
                  <p className={cn(
                    "text-sm font-medium",
                    isPositive ? "text-primary" : "text-destructive"
                  )}>
                    {isPositive ? "+" : ""}₹{pnl.toFixed(2)} ({isPositive ? "+" : ""}{pnlPercent.toFixed(2)}%)
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
