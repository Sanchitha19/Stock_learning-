import { Stock } from "@/types";
import { cn } from "@/lib/utils";
import { TrendingUp, TrendingDown } from "lucide-react";

interface StockChartProps {
  stock: Stock;
  className?: string;
}

export function StockChart({ stock, className }: StockChartProps) {
  const { priceHistory } = stock;
  const min = Math.min(...priceHistory);
  const max = Math.max(...priceHistory);
  const range = max - min;
  const isPositive = stock.change >= 0;

  const points = priceHistory.map((price, i) => {
    const x = (i / (priceHistory.length - 1)) * 100;
    const y = 100 - ((price - min) / range) * 100;
    return `${x},${y}`;
  }).join(' ');

  const areaPoints = `0,100 ${points} 100,100`;

  return (
    <div className={cn("rounded-xl border border-border bg-card p-4", className)}>
      <div className="flex items-start justify-between mb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-lg font-bold">{stock.symbol}</span>
            <span className={cn(
              "flex items-center gap-1 text-sm font-medium px-2 py-0.5 rounded-full",
              isPositive ? "bg-primary/10 text-primary" : "bg-destructive/10 text-destructive"
            )}>
              {isPositive ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
              {isPositive ? "+" : ""}{stock.changePercent}%
            </span>
          </div>
          <p className="text-sm text-muted-foreground">{stock.name}</p>
        </div>
        <div className="text-right">
          <p className="text-2xl font-bold">₹{stock.price.toLocaleString()}</p>
          <p className={cn(
            "text-sm",
            isPositive ? "text-primary" : "text-destructive"
          )}>
            {isPositive ? "+" : ""}₹{stock.change.toFixed(2)}
          </p>
        </div>
      </div>

      <div className="h-32 relative">
        <svg
          viewBox="0 0 100 100"
          preserveAspectRatio="none"
          className="w-full h-full"
        >
          {/* Gradient fill */}
          <defs>
            <linearGradient id={`gradient-${stock.symbol}`} x1="0" x2="0" y1="0" y2="1">
              <stop 
                offset="0%" 
                stopColor={isPositive ? "hsl(152 69% 45%)" : "hsl(0 84% 60%)"} 
                stopOpacity="0.3" 
              />
              <stop 
                offset="100%" 
                stopColor={isPositive ? "hsl(152 69% 45%)" : "hsl(0 84% 60%)"} 
                stopOpacity="0" 
              />
            </linearGradient>
          </defs>
          
          {/* Area fill */}
          <polygon
            points={areaPoints}
            fill={`url(#gradient-${stock.symbol})`}
          />
          
          {/* Line */}
          <polyline
            points={points}
            fill="none"
            stroke={isPositive ? "hsl(152 69% 45%)" : "hsl(0 84% 60%)"}
            strokeWidth="2"
            vectorEffect="non-scaling-stroke"
          />
        </svg>
      </div>

      <div className="flex justify-between mt-4 text-xs text-muted-foreground">
        <div>
          <span className="block text-foreground font-medium">₹{stock.low.toLocaleString()}</span>
          <span>Low</span>
        </div>
        <div className="text-center">
          <span className="block text-foreground font-medium">{(stock.volume / 1000000).toFixed(1)}M</span>
          <span>Volume</span>
        </div>
        <div className="text-right">
          <span className="block text-foreground font-medium">₹{stock.high.toLocaleString()}</span>
          <span>High</span>
        </div>
      </div>
    </div>
  );
}
