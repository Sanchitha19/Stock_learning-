import { useState } from "react";
import { QuizQuestion } from "@/types";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { CheckCircle2, XCircle, ArrowRight } from "lucide-react";

interface QuizProps {
  questions: QuizQuestion[];
  onComplete: (score: number) => void;
}

export function Quiz({ questions, onComplete }: QuizProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [correctAnswers, setCorrectAnswers] = useState(0);

  const question = questions[currentQuestion];
  const isCorrect = selectedAnswer === question.correctAnswer;
  const isLastQuestion = currentQuestion === questions.length - 1;

  const handleSelect = (index: number) => {
    if (showResult) return;
    setSelectedAnswer(index);
  };

  const handleSubmit = () => {
    if (selectedAnswer === null) return;
    
    if (!showResult) {
      setShowResult(true);
      if (isCorrect) {
        setCorrectAnswers(prev => prev + 1);
      }
    } else {
      if (isLastQuestion) {
        const finalCorrect = correctAnswers + (isCorrect ? 0 : 0);
        const score = Math.round((finalCorrect / questions.length) * 100);
        onComplete(score);
      } else {
        setCurrentQuestion(prev => prev + 1);
        setSelectedAnswer(null);
        setShowResult(false);
      }
    }
  };

  return (
    <div className="rounded-xl border border-border bg-card p-6">
      <div className="mb-6 flex items-center justify-between">
        <h3 className="text-lg font-semibold">Comprehension Quiz</h3>
        <span className="text-sm text-muted-foreground">
          Question {currentQuestion + 1} of {questions.length}
        </span>
      </div>

      <div className="mb-6">
        <div className="h-1 overflow-hidden rounded-full bg-secondary">
          <div 
            className="h-full bg-primary transition-all duration-300"
            style={{ width: `${((currentQuestion + (showResult ? 1 : 0)) / questions.length) * 100}%` }}
          />
        </div>
      </div>

      <p className="mb-6 text-lg">{question.question}</p>

      <div className="space-y-3 mb-6">
        {question.options.map((option, index) => {
          const isSelected = selectedAnswer === index;
          const isCorrectOption = index === question.correctAnswer;
          
          return (
            <button
              key={index}
              onClick={() => handleSelect(index)}
              disabled={showResult}
              className={cn(
                "w-full text-left p-4 rounded-lg border transition-all duration-200",
                !showResult && "hover:border-primary/50 hover:bg-secondary/50",
                isSelected && !showResult && "border-primary bg-primary/10",
                showResult && isCorrectOption && "border-primary bg-primary/10",
                showResult && isSelected && !isCorrectOption && "border-destructive bg-destructive/10"
              )}
            >
              <div className="flex items-center justify-between">
                <span>{option}</span>
                {showResult && isCorrectOption && (
                  <CheckCircle2 className="h-5 w-5 text-primary" />
                )}
                {showResult && isSelected && !isCorrectOption && (
                  <XCircle className="h-5 w-5 text-destructive" />
                )}
              </div>
            </button>
          );
        })}
      </div>

      {showResult && (
        <div className={cn(
          "mb-6 p-4 rounded-lg",
          isCorrect ? "bg-primary/10 border border-primary/30" : "bg-destructive/10 border border-destructive/30"
        )}>
          <p className={cn(
            "font-medium mb-1",
            isCorrect ? "text-primary" : "text-destructive"
          )}>
            {isCorrect ? "Correct!" : "Incorrect"}
          </p>
          <p className="text-sm text-muted-foreground">{question.explanation}</p>
        </div>
      )}

      <Button
        onClick={handleSubmit}
        disabled={selectedAnswer === null}
        className="w-full"
        size="lg"
      >
        {!showResult ? "Check Answer" : isLastQuestion ? "Complete Quiz" : "Next Question"}
        <ArrowRight className="ml-2 h-4 w-4" />
      </Button>
    </div>
  );
}
