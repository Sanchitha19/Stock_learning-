import { cn } from "@/lib/utils";
import { lessons } from "@/data/lessons";
import { useProgressStore } from "@/store/progressStore";
import { Check, Lock, Play } from "lucide-react";
import { Link } from "react-router-dom";

interface LessonCardProps {
  lessonId: string;
  className?: string;
}

export function LessonCard({ lessonId, className }: LessonCardProps) {
  const lesson = lessons.find(l => l.id === lessonId);
  const { progress } = useProgressStore();
  
  if (!lesson) return null;
  
  const isCompleted = progress.completedLessons.includes(lessonId);
  const quizScore = progress.quizScores[lessonId];
  const lessonIndex = lessons.findIndex(l => l.id === lessonId);
  const previousLessonsCompleted = lessons
    .slice(0, lessonIndex)
    .every(l => progress.completedLessons.includes(l.id));
  const isLocked = lessonIndex > 0 && !previousLessonsCompleted;
  
  return (
    <Link
      to={isLocked ? "#" : `/lessons/${lessonId}`}
      className={cn(
        "group relative block rounded-xl border border-border bg-card p-6 transition-all duration-300",
        isLocked 
          ? "cursor-not-allowed opacity-50" 
          : "hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5",
        className
      )}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
            <span className="px-2 py-0.5 rounded-full bg-secondary">{lesson.module}</span>
            <span>{lesson.duration}</span>
          </div>
          
          <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors">
            {lesson.title}
          </h3>
          
          <p className="text-sm text-muted-foreground line-clamp-2">
            {lesson.description}
          </p>
          
          {quizScore !== undefined && (
            <div className="mt-3 text-sm">
              <span className={cn(
                "font-medium",
                quizScore >= 70 ? "text-primary" : "text-warning"
              )}>
                Quiz Score: {quizScore}%
              </span>
            </div>
          )}
        </div>
        
        <div className={cn(
          "flex h-10 w-10 items-center justify-center rounded-full transition-colors",
          isCompleted ? "bg-primary text-primary-foreground" :
          isLocked ? "bg-secondary text-muted-foreground" :
          "bg-secondary text-foreground group-hover:bg-primary group-hover:text-primary-foreground"
        )}>
          {isLocked ? (
            <Lock className="h-4 w-4" />
          ) : isCompleted ? (
            <Check className="h-4 w-4" />
          ) : (
            <Play className="h-4 w-4" />
          )}
        </div>
      </div>
      
      {/* Progress bar */}
      {isCompleted && (
        <div className="absolute bottom-0 left-0 right-0 h-1 overflow-hidden rounded-b-xl">
          <div className="h-full bg-primary" />
        </div>
      )}
    </Link>
  );
}
