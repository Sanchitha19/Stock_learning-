import { Navbar } from "@/components/Navbar";
import { LessonCard } from "@/components/LessonCard";
import { lessons } from "@/data/lessons";
import { useProgressStore } from "@/store/progressStore";
import { Progress } from "@/components/ui/progress";
import { BookOpen, Trophy, Clock } from "lucide-react";

const LessonsPage = () => {
  const { progress } = useProgressStore();
  const completedCount = progress.completedLessons.length;
  const totalLessons = lessons.length;
  const progressPercent = (completedCount / totalLessons) * 100;
  
  const avgScore = Object.values(progress.quizScores).length > 0
    ? Object.values(progress.quizScores).reduce((a, b) => a + b, 0) / Object.values(progress.quizScores).length
    : 0;

  // Group lessons by module
  const modules = lessons.reduce((acc, lesson) => {
    if (!acc[lesson.module]) acc[lesson.module] = [];
    acc[lesson.module].push(lesson);
    return acc;
  }, {} as Record<string, typeof lessons>);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-20 pb-12 px-4">
        <div className="container mx-auto max-w-5xl">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Lessons</h1>
            <p className="text-muted-foreground">
              Complete all lessons to unlock virtual trading
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mb-8">
            <div className="p-4 rounded-xl border border-border bg-card">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <BookOpen className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{completedCount}/{totalLessons}</p>
                  <p className="text-xs text-muted-foreground">Completed</p>
                </div>
              </div>
            </div>
            
            <div className="p-4 rounded-xl border border-border bg-card">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Trophy className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{avgScore.toFixed(0)}%</p>
                  <p className="text-xs text-muted-foreground">Avg Score</p>
                </div>
              </div>
            </div>
            
            <div className="p-4 rounded-xl border border-border bg-card">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Clock className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{progress.totalTimeSpent}m</p>
                  <p className="text-xs text-muted-foreground">Time Spent</p>
                </div>
              </div>
            </div>
          </div>

          {/* Progress bar */}
          <div className="mb-8 p-4 rounded-xl border border-border bg-card">
            <div className="flex justify-between text-sm mb-2">
              <span className="font-medium">Overall Progress</span>
              <span className="text-muted-foreground">{progressPercent.toFixed(0)}%</span>
            </div>
            <Progress value={progressPercent} className="h-2" />
            {progressPercent === 100 && !progress.tradingUnlocked && (
              <p className="text-sm text-primary mt-2">
                All lessons completed! You can now access the trading simulator.
              </p>
            )}
          </div>

          {/* Lessons by module */}
          {Object.entries(modules).map(([moduleName, moduleLessons]) => (
            <div key={moduleName} className="mb-8">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-primary" />
                {moduleName}
              </h2>
              <div className="grid gap-4 md:grid-cols-2">
                {moduleLessons.map((lesson) => (
                  <LessonCard key={lesson.id} lessonId={lesson.id} />
                ))}
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
};

export default LessonsPage;
