import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { lessons } from "@/data/lessons";
import { useProgressStore } from "@/store/progressStore";
import { 
  BookOpen, 
  TrendingUp, 
  Brain, 
  Target, 
  Shield, 
  ChevronRight,
  CheckCircle2,
  Play
} from "lucide-react";

const features = [
  {
    icon: BookOpen,
    title: "Structured Learning",
    description: "5 comprehensive lessons covering market fundamentals to risk management"
  },
  {
    icon: Play,
    title: "Video Learning",
    description: "Curated YouTube videos from top educators to reinforce concepts"
  },
  {
    icon: TrendingUp,
    title: "Virtual Trading",
    description: "Practice with ₹1,00,000 virtual capital in realistic market conditions"
  },
  {
    icon: Brain,
    title: "AI Analysis",
    description: "Get personalized feedback on your trading decisions"
  },
  {
    icon: Target,
    title: "Quiz Validation",
    description: "Test your knowledge before accessing trading features"
  },
  {
    icon: Shield,
    title: "Risk Management",
    description: "Learn stop-loss, position sizing, and capital preservation"
  }
];

const Index = () => {
  const { progress } = useProgressStore();
  const completedCount = progress.completedLessons.length;
  const totalLessons = lessons.length;
  const progressPercent = (completedCount / totalLessons) * 100;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative pt-24 pb-20 px-4 overflow-hidden">
        {/* Background glow */}
        <div className="absolute inset-0 bg-glow opacity-30" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        
        <div className="container mx-auto relative">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6 animate-fade-in">
              <TrendingUp className="h-4 w-4" />
              AI-Powered Stock Market Education
            </div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 animate-slide-up">
              Master Stock Trading
              <span className="block text-gradient">With Confidence</span>
            </h1>
            
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto animate-slide-up" style={{ animationDelay: '0.1s' }}>
              Learn to buy and sell stocks through structured lessons, practice with virtual money, 
              and get AI-powered feedback on your trades. Go from beginner to confident trader.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up" style={{ animationDelay: '0.2s' }}>
              <Button asChild variant="hero" size="xl">
                <Link to="/lessons">
                  {completedCount > 0 ? 'Continue Learning' : 'Start Learning'}
                  <ChevronRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              
              {progress.tradingUnlocked && (
                <Button asChild variant="outline" size="xl">
                  <Link to="/trading">
                    Open Trading
                    <TrendingUp className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
              )}
            </div>
            
            {/* Progress indicator */}
            {completedCount > 0 && (
              <div className="mt-12 max-w-md mx-auto animate-fade-in" style={{ animationDelay: '0.3s' }}>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-muted-foreground">Your Progress</span>
                  <span className="font-medium">{completedCount}/{totalLessons} lessons</span>
                </div>
                <div className="h-2 rounded-full bg-secondary overflow-hidden">
                  <div 
                    className="h-full bg-primary transition-all duration-500 rounded-full"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 border-t border-border">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Everything You Need to Succeed</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              A complete learning system designed to take you from complete beginner to confident trader
            </p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div 
                  key={feature.title}
                  className="group p-6 rounded-xl border border-border bg-card hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5 transition-all duration-300"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                    <Icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Course Overview */}
      <section className="py-20 px-4 bg-secondary/30">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Learning Path</h2>
            <p className="text-muted-foreground">
              Complete all lessons to unlock the virtual trading simulator
            </p>
          </div>
          
          <div className="max-w-2xl mx-auto space-y-4">
            {lessons.map((lesson, index) => {
              const isCompleted = progress.completedLessons.includes(lesson.id);
              
              return (
                <Link
                  key={lesson.id}
                  to={`/lessons/${lesson.id}`}
                  className="flex items-center gap-4 p-4 rounded-xl border border-border bg-card hover:border-primary/50 transition-all duration-200"
                >
                  <div className={`
                    w-10 h-10 rounded-full flex items-center justify-center shrink-0
                    ${isCompleted ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground'}
                  `}>
                    {isCompleted ? (
                      <CheckCircle2 className="h-5 w-5" />
                    ) : (
                      <span className="font-semibold">{index + 1}</span>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold truncate">{lesson.title}</h3>
                    <p className="text-sm text-muted-foreground truncate">{lesson.description}</p>
                  </div>
                  <span className="text-xs text-muted-foreground shrink-0">{lesson.duration}</span>
                </Link>
              );
            })}
          </div>
          
          <div className="text-center mt-8">
            <Button asChild variant="hero" size="lg">
              <Link to="/lessons">
                Start Your Journey
                <ChevronRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-border">
        <div className="container mx-auto text-center text-sm text-muted-foreground">
          <p>TradeTutor Pro — Learn to trade with confidence</p>
          <p className="mt-2">Virtual trading only. Not financial advice.</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
