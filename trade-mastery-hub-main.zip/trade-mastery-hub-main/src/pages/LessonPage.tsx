import { useState, useEffect } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { Quiz } from "@/components/Quiz";
import { Button } from "@/components/ui/button";
import { getLesson, getNextLesson, lessons } from "@/data/lessons";
import { useProgressStore } from "@/store/progressStore";
import { ChevronLeft, ChevronRight, Clock, CheckCircle2, Play } from "lucide-react";
import { toast } from "sonner";

const LessonPage = () => {
  const { lessonId } = useParams();
  const navigate = useNavigate();
  const lesson = getLesson(lessonId || '');
  const nextLesson = getNextLesson(lessonId || '');
  const { progress, completeLesson, setQuizScore, addTimeSpent, unlockTrading } = useProgressStore();
  
  const [showQuiz, setShowQuiz] = useState(false);
  const [startTime] = useState(Date.now());
  
  const isCompleted = progress.completedLessons.includes(lessonId || '');
  const quizScore = progress.quizScores[lessonId || ''];
  const lessonIndex = lessons.findIndex(l => l.id === lessonId);
  
  useEffect(() => {
    return () => {
      const timeSpent = Math.round((Date.now() - startTime) / 60000);
      if (timeSpent > 0) {
        addTimeSpent(timeSpent);
      }
    };
  }, [startTime, addTimeSpent]);

  if (!lesson) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="pt-24 px-4 text-center">
          <h1 className="text-2xl font-bold mb-4">Lesson not found</h1>
          <Button asChild>
            <Link to="/lessons">Back to Lessons</Link>
          </Button>
        </div>
      </div>
    );
  }

  const handleQuizComplete = (score: number) => {
    setQuizScore(lesson.id, score);
    
    if (score >= 70) {
      completeLesson(lesson.id);
      
      // Check if all lessons are completed
      const allCompleted = lessons.every(l => 
        progress.completedLessons.includes(l.id) || l.id === lesson.id
      );
      
      if (allCompleted) {
        unlockTrading();
        toast.success("Congratulations! You've unlocked the Trading Simulator!");
      } else {
        toast.success("Lesson completed! Great job!");
      }
    } else {
      toast.error("You need 70% to pass. Review the lesson and try again.");
    }
    
    setShowQuiz(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-20 pb-12 px-4">
        <div className="container mx-auto max-w-4xl">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
            <Link to="/lessons" className="hover:text-foreground transition-colors">
              Lessons
            </Link>
            <ChevronRight className="h-4 w-4" />
            <span className="text-foreground">{lesson.title}</span>
          </div>

          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-3">
              <span className="px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium">
                {lesson.module}
              </span>
              <span className="flex items-center gap-1 text-sm text-muted-foreground">
                <Clock className="h-4 w-4" />
                {lesson.duration}
              </span>
              {isCompleted && (
                <span className="flex items-center gap-1 text-sm text-primary">
                  <CheckCircle2 className="h-4 w-4" />
                  Completed
                </span>
              )}
            </div>
            
            <h1 className="text-3xl font-bold mb-2">
              Lesson {lessonIndex + 1}: {lesson.title}
            </h1>
            <p className="text-lg text-muted-foreground">{lesson.description}</p>
          </div>

          {/* Video */}
          <div className="mb-8 rounded-xl overflow-hidden border border-border bg-card">
            <div className="aspect-video">
              <iframe
                src={lesson.videoUrl}
                title={lesson.title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="w-full h-full"
              />
            </div>
          </div>

          {/* Content */}
          <div className="mb-8 space-y-6">
            {lesson.content.map((paragraph, index) => (
              <p key={index} className="text-muted-foreground leading-relaxed">
                {paragraph}
              </p>
            ))}
          </div>

          {/* Key Takeaways */}
          <div className="mb-8 p-6 rounded-xl border border-border bg-card">
            <h2 className="text-xl font-semibold mb-4">Key Takeaways</h2>
            <ul className="space-y-3">
              {lesson.keyTakeaways.map((takeaway, index) => (
                <li key={index} className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                  <span>{takeaway}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Quiz or Quiz Button */}
          {showQuiz ? (
            <Quiz questions={lesson.quiz} onComplete={handleQuizComplete} />
          ) : (
            <div className="mb-8">
              <Button 
                onClick={() => setShowQuiz(true)} 
                size="lg" 
                className="w-full"
                variant={isCompleted ? "outline" : "hero"}
              >
                <Play className="mr-2 h-5 w-5" />
                {isCompleted ? 'Retake Quiz' : 'Take Quiz to Complete Lesson'}
              </Button>
              
              {quizScore !== undefined && (
                <p className="text-center text-sm mt-3 text-muted-foreground">
                  Your best score: <span className={quizScore >= 70 ? "text-primary" : "text-destructive"}>{quizScore}%</span>
                  {quizScore < 70 && " (Need 70% to pass)"}
                </p>
              )}
            </div>
          )}

          {/* Navigation */}
          <div className="flex justify-between items-center pt-8 border-t border-border">
            <Button asChild variant="outline">
              <Link to="/lessons">
                <ChevronLeft className="mr-2 h-4 w-4" />
                All Lessons
              </Link>
            </Button>
            
            {nextLesson && isCompleted && (
              <Button asChild>
                <Link to={`/lessons/${nextLesson.id}`}>
                  Next: {nextLesson.title}
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            )}
            
            {!nextLesson && isCompleted && (
              <Button asChild variant="hero">
                <Link to="/trading">
                  Start Trading
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default LessonPage;
