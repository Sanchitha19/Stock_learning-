import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { StockChart } from "@/components/StockChart";
import { TradeForm } from "@/components/TradeForm";
import { Portfolio } from "@/components/Portfolio";
import { Button } from "@/components/ui/button";
import { initialStocks, updateStockPrice } from "@/data/stocks";
import { useProgressStore } from "@/store/progressStore";
import { lessons } from "@/data/lessons";
import { Stock } from "@/types";
import { Lock, Wallet, TrendingUp, History } from "lucide-react";
import { cn } from "@/lib/utils";

const TradingPage = () => {
  const { progress } = useProgressStore();
  const [stocks, setStocks] = useState<Stock[]>(initialStocks);
  const [selectedStock, setSelectedStock] = useState<Stock>(initialStocks[0]);
  const [activeTab, setActiveTab] = useState<'trade' | 'portfolio' | 'history'>('trade');
  
  const completedCount = progress.completedLessons.length;
  const totalLessons = lessons.length;
  const allLessonsCompleted = completedCount >= totalLessons;
  const tradingUnlocked = progress.tradingUnlocked || allLessonsCompleted;

  // Simulate real-time price updates
  useEffect(() => {
    if (!tradingUnlocked) return;
    
    const interval = setInterval(() => {
      setStocks(prevStocks => {
        const updated = prevStocks.map(updateStockPrice);
        // Update selected stock if it changed
        const updatedSelected = updated.find(s => s.symbol === selectedStock.symbol);
        if (updatedSelected) {
          setSelectedStock(updatedSelected);
        }
        return updated;
      });
    }, 3000);

    return () => clearInterval(interval);
  }, [tradingUnlocked, selectedStock.symbol]);

  if (!tradingUnlocked) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        
        <main className="pt-20 pb-12 px-4">
          <div className="container mx-auto max-w-2xl">
            <div className="text-center py-20">
              <div className="w-20 h-20 rounded-full bg-secondary flex items-center justify-center mx-auto mb-6">
                <Lock className="h-10 w-10 text-muted-foreground" />
              </div>
              
              <h1 className="text-3xl font-bold mb-4">Trading Locked</h1>
              <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                Complete all lessons and pass the quizzes to unlock the virtual trading simulator. 
                This ensures you have the knowledge to trade responsibly.
              </p>
              
              <div className="p-4 rounded-xl border border-border bg-card inline-block mb-8">
                <p className="text-sm text-muted-foreground mb-2">Progress</p>
                <p className="text-2xl font-bold">
                  {completedCount} / {totalLessons} <span className="text-muted-foreground text-lg">lessons</span>
                </p>
              </div>
              
              <div>
                <Button asChild variant="hero" size="lg">
                  <Link to="/lessons">
                    Continue Learning
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-20 pb-12 px-4">
        <div className="container mx-auto">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
            <div>
              <h1 className="text-2xl font-bold">Virtual Trading</h1>
              <p className="text-muted-foreground">Practice with ₹1,00,000 virtual capital</p>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-card border border-border">
                <Wallet className="h-4 w-4 text-primary" />
                <span className="text-sm text-muted-foreground">Balance:</span>
                <span className="font-semibold">₹{progress.virtualBalance.toLocaleString()}</span>
              </div>
            </div>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Left Column - Stock List & Chart */}
            <div className="lg:col-span-2 space-y-6">
              {/* Stock List */}
              <div className="rounded-xl border border-border bg-card overflow-hidden">
                <div className="p-4 border-b border-border">
                  <h2 className="font-semibold">Market Watch</h2>
                </div>
                <div className="divide-y divide-border max-h-48 overflow-y-auto">
                  {stocks.map((stock) => (
                    <button
                      key={stock.symbol}
                      onClick={() => setSelectedStock(stock)}
                      className={cn(
                        "w-full flex items-center justify-between p-3 hover:bg-secondary/50 transition-colors text-left",
                        selectedStock.symbol === stock.symbol && "bg-secondary"
                      )}
                    >
                      <div>
                        <p className="font-medium">{stock.symbol}</p>
                        <p className="text-xs text-muted-foreground">{stock.name}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">₹{stock.price.toLocaleString()}</p>
                        <p className={cn(
                          "text-xs",
                          stock.change >= 0 ? "text-primary" : "text-destructive"
                        )}>
                          {stock.change >= 0 ? "+" : ""}{stock.changePercent}%
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Chart */}
              <StockChart stock={selectedStock} />
            </div>

            {/* Right Column - Trade Form / Portfolio / History */}
            <div className="space-y-6">
              {/* Tabs */}
              <div className="flex rounded-lg bg-secondary p-1">
                <button
                  onClick={() => setActiveTab('trade')}
                  className={cn(
                    "flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors",
                    activeTab === 'trade' ? "bg-card shadow" : "hover:text-foreground text-muted-foreground"
                  )}
                >
                  <TrendingUp className="h-4 w-4" />
                  Trade
                </button>
                <button
                  onClick={() => setActiveTab('portfolio')}
                  className={cn(
                    "flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors",
                    activeTab === 'portfolio' ? "bg-card shadow" : "hover:text-foreground text-muted-foreground"
                  )}
                >
                  <Wallet className="h-4 w-4" />
                  Holdings
                </button>
                <button
                  onClick={() => setActiveTab('history')}
                  className={cn(
                    "flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors",
                    activeTab === 'history' ? "bg-card shadow" : "hover:text-foreground text-muted-foreground"
                  )}
                >
                  <History className="h-4 w-4" />
                  History
                </button>
              </div>

              {/* Tab Content */}
              {activeTab === 'trade' && (
                <TradeForm 
                  stock={selectedStock} 
                  onTrade={() => {
                    // Refresh stock prices after trade
                    setStocks(prevStocks => prevStocks.map(updateStockPrice));
                  }} 
                />
              )}
              
              {activeTab === 'portfolio' && <Portfolio />}
              
              {activeTab === 'history' && (
                <div className="rounded-xl border border-border bg-card overflow-hidden">
                  <div className="p-4 border-b border-border">
                    <h3 className="font-semibold">Trade History</h3>
                  </div>
                  {progress.tradeHistory.length === 0 ? (
                    <div className="p-6 text-center text-muted-foreground">
                      No trades yet. Start trading!
                    </div>
                  ) : (
                    <div className="divide-y divide-border max-h-96 overflow-y-auto">
                      {progress.tradeHistory.slice(0, 20).map((trade) => (
                        <div key={trade.id} className="p-3">
                          <div className="flex justify-between items-start">
                            <div>
                              <span className={cn(
                                "text-xs font-medium px-2 py-0.5 rounded",
                                trade.type === 'BUY' ? "bg-primary/10 text-primary" : "bg-destructive/10 text-destructive"
                              )}>
                                {trade.type}
                              </span>
                              <p className="font-medium mt-1">{trade.symbol}</p>
                              <p className="text-xs text-muted-foreground">
                                {trade.quantity} @ ₹{trade.price.toFixed(2)}
                              </p>
                            </div>
                            <div className="text-right">
                              <p className="font-medium">
                                ₹{(trade.quantity * trade.price).toLocaleString()}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {new Date(trade.timestamp).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default TradingPage;
