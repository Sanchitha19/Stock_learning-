import { Link } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useProgressStore } from "@/store/progressStore";
import { lessons } from "@/data/lessons";
import { 
  BookOpen, 
  Trophy, 
  TrendingUp, 
  Target,
  Clock,
  Wallet,
  BarChart3,
  CheckCircle2,
  AlertCircle
} from "lucide-react";
import { cn } from "@/lib/utils";

const DashboardPage = () => {
  const { progress } = useProgressStore();
  
  const completedCount = progress.completedLessons.length;
  const totalLessons = lessons.length;
  const progressPercent = (completedCount / totalLessons) * 100;
  
  const quizScores = Object.values(progress.quizScores);
  const avgScore = quizScores.length > 0
    ? quizScores.reduce((a, b) => a + b, 0) / quizScores.length
    : 0;
  
  const totalTrades = progress.tradeHistory.length;
  const buyTrades = progress.tradeHistory.filter(t => t.type === 'BUY').length;
  const sellTrades = progress.tradeHistory.filter(t => t.type === 'SELL').length;
  
  const portfolioValue = progress.portfolio.reduce(
    (sum, item) => sum + item.quantity * item.currentPrice,
    0
  );
  
  const totalPnL = progress.portfolio.reduce(
    (sum, item) => sum + (item.currentPrice - item.avgPrice) * item.quantity,
    0
  );
  
  const totalAssets = progress.virtualBalance + portfolioValue;
  const initialCapital = 100000;
  const overallReturn = ((totalAssets - initialCapital) / initialCapital) * 100;

  // Trading insights
  const tradesWithStopLoss = progress.tradeHistory.filter(t => t.stopLoss).length;
  const stopLossUsage = totalTrades > 0 ? (tradesWithStopLoss / totalTrades) * 100 : 0;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-20 pb-12 px-4">
        <div className="container mx-auto max-w-6xl">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
            <p className="text-muted-foreground">Track your learning progress and trading performance</p>
          </div>

          {/* Main Stats */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <div className="p-5 rounded-xl border border-border bg-card">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <BookOpen className="h-5 w-5 text-primary" />
                </div>
                <span className="text-sm text-muted-foreground">Lessons</span>
              </div>
              <p className="text-2xl font-bold">{completedCount}/{totalLessons}</p>
              <Progress value={progressPercent} className="h-1.5 mt-2" />
            </div>
            
            <div className="p-5 rounded-xl border border-border bg-card">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Trophy className="h-5 w-5 text-primary" />
                </div>
                <span className="text-sm text-muted-foreground">Avg Quiz Score</span>
              </div>
              <p className="text-2xl font-bold">{avgScore.toFixed(0)}%</p>
              <p className="text-xs text-muted-foreground mt-1">
                {quizScores.length} quizzes taken
              </p>
            </div>
            
            <div className="p-5 rounded-xl border border-border bg-card">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Wallet className="h-5 w-5 text-primary" />
                </div>
                <span className="text-sm text-muted-foreground">Total Assets</span>
              </div>
              <p className="text-2xl font-bold">₹{totalAssets.toLocaleString()}</p>
              <p className={cn(
                "text-xs mt-1",
                overallReturn >= 0 ? "text-primary" : "text-destructive"
              )}>
                {overallReturn >= 0 ? "+" : ""}{overallReturn.toFixed(2)}% return
              </p>
            </div>
            
            <div className="p-5 rounded-xl border border-border bg-card">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <BarChart3 className="h-5 w-5 text-primary" />
                </div>
                <span className="text-sm text-muted-foreground">Total Trades</span>
              </div>
              <p className="text-2xl font-bold">{totalTrades}</p>
              <p className="text-xs text-muted-foreground mt-1">
                {buyTrades} buys · {sellTrades} sells
              </p>
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            {/* Learning Progress */}
            <div className="rounded-xl border border-border bg-card overflow-hidden">
              <div className="p-4 border-b border-border">
                <h2 className="font-semibold flex items-center gap-2">
                  <BookOpen className="h-4 w-4 text-primary" />
                  Learning Progress
                </h2>
              </div>
              <div className="p-4 space-y-3">
                {lessons.map((lesson) => {
                  const isCompleted = progress.completedLessons.includes(lesson.id);
                  const score = progress.quizScores[lesson.id];
                  
                  return (
                    <Link
                      key={lesson.id}
                      to={`/lessons/${lesson.id}`}
                      className="flex items-center gap-3 p-3 rounded-lg hover:bg-secondary/50 transition-colors"
                    >
                      <div className={cn(
                        "w-8 h-8 rounded-full flex items-center justify-center shrink-0",
                        isCompleted ? "bg-primary text-primary-foreground" : "bg-secondary"
                      )}>
                        {isCompleted ? (
                          <CheckCircle2 className="h-4 w-4" />
                        ) : (
                          <span className="text-sm">{lesson.order}</span>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className={cn(
                          "text-sm font-medium truncate",
                          isCompleted && "text-muted-foreground"
                        )}>
                          {lesson.title}
                        </p>
                      </div>
                      {score !== undefined && (
                        <span className={cn(
                          "text-xs font-medium px-2 py-1 rounded",
                          score >= 70 ? "bg-primary/10 text-primary" : "bg-warning/10 text-warning"
                        )}>
                          {score}%
                        </span>
                      )}
                    </Link>
                  );
                })}
              </div>
              
              {completedCount < totalLessons && (
                <div className="p-4 border-t border-border">
                  <Button asChild className="w-full">
                    <Link to="/lessons">Continue Learning</Link>
                  </Button>
                </div>
              )}
            </div>

            {/* Trading Insights */}
            <div className="space-y-6">
              {/* Portfolio Summary */}
              <div className="rounded-xl border border-border bg-card overflow-hidden">
                <div className="p-4 border-b border-border">
                  <h2 className="font-semibold flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-primary" />
                    Portfolio Summary
                  </h2>
                </div>
                <div className="p-4">
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Cash Balance</p>
                      <p className="text-lg font-semibold">₹{progress.virtualBalance.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Invested Value</p>
                      <p className="text-lg font-semibold">₹{portfolioValue.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Unrealized P&L</p>
                      <p className={cn(
                        "text-lg font-semibold",
                        totalPnL >= 0 ? "text-primary" : "text-destructive"
                      )}>
                        {totalPnL >= 0 ? "+" : ""}₹{totalPnL.toFixed(2)}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Holdings</p>
                      <p className="text-lg font-semibold">{progress.portfolio.length} stocks</p>
                    </div>
                  </div>
                  
                  {progress.tradingUnlocked && (
                    <Button asChild variant="outline" className="w-full">
                      <Link to="/trading">Open Trading</Link>
                    </Button>
                  )}
                </div>
              </div>

              {/* Trading Tips */}
              <div className="rounded-xl border border-border bg-card overflow-hidden">
                <div className="p-4 border-b border-border">
                  <h2 className="font-semibold flex items-center gap-2">
                    <Target className="h-4 w-4 text-primary" />
                    Trading Insights
                  </h2>
                </div>
                <div className="p-4 space-y-3">
                  {totalTrades === 0 ? (
                    <p className="text-sm text-muted-foreground">
                      Start trading to see personalized insights about your performance.
                    </p>
                  ) : (
                    <>
                      <div className="flex items-start gap-3 p-3 rounded-lg bg-secondary/30">
                        {stopLossUsage >= 50 ? (
                          <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                        ) : (
                          <AlertCircle className="h-5 w-5 text-warning shrink-0 mt-0.5" />
                        )}
                        <div>
                          <p className="text-sm font-medium">Stop Loss Usage</p>
                          <p className="text-xs text-muted-foreground">
                            {stopLossUsage.toFixed(0)}% of your trades use stop-loss orders.
                            {stopLossUsage < 50 && " Consider using stop-losses more often to protect your capital."}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-start gap-3 p-3 rounded-lg bg-secondary/30">
                        <Clock className="h-5 w-5 text-info shrink-0 mt-0.5" />
                        <div>
                          <p className="text-sm font-medium">Time Invested</p>
                          <p className="text-xs text-muted-foreground">
                            You've spent {progress.totalTimeSpent} minutes learning.
                            Keep practicing to improve your skills!
                          </p>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default DashboardPage;
