import { Stock } from "@/types";

const generatePriceHistory = (basePrice: number, volatility: number = 0.02): number[] => {
  const history: number[] = [];
  let price = basePrice * (0.9 + Math.random() * 0.2);
  
  for (let i = 0; i < 50; i++) {
    const change = (Math.random() - 0.5) * 2 * volatility * price;
    price = Math.max(price + change, basePrice * 0.5);
    history.push(Number(price.toFixed(2)));
  }
  
  return history;
};

export const initialStocks: Stock[] = [
  {
    symbol: "RELIANCE",
    name: "Reliance Industries",
    price: 2456.75,
    change: 23.45,
    changePercent: 0.96,
    high: 2478.00,
    low: 2430.50,
    volume: 8234567,
    priceHistory: generatePriceHistory(2456.75)
  },
  {
    symbol: "TCS",
    name: "Tata Consultancy Services",
    price: 3567.80,
    change: -12.30,
    changePercent: -0.34,
    high: 3590.00,
    low: 3545.25,
    volume: 2345678,
    priceHistory: generatePriceHistory(3567.80)
  },
  {
    symbol: "INFY",
    name: "Infosys Limited",
    price: 1456.25,
    change: 8.75,
    changePercent: 0.60,
    high: 1468.50,
    low: 1445.00,
    volume: 5678901,
    priceHistory: generatePriceHistory(1456.25)
  },
  {
    symbol: "HDFC",
    name: "HDFC Bank",
    price: 1678.90,
    change: -5.60,
    changePercent: -0.33,
    high: 1695.00,
    low: 1670.25,
    volume: 3456789,
    priceHistory: generatePriceHistory(1678.90)
  },
  {
    symbol: "WIPRO",
    name: "Wipro Limited",
    price: 456.35,
    change: 4.20,
    changePercent: 0.93,
    high: 462.00,
    low: 450.75,
    volume: 4567890,
    priceHistory: generatePriceHistory(456.35)
  },
  {
    symbol: "TATASTEEL",
    name: "Tata Steel",
    price: 134.50,
    change: 2.85,
    changePercent: 2.16,
    high: 136.75,
    low: 131.25,
    volume: 12345678,
    priceHistory: generatePriceHistory(134.50, 0.03)
  },
  {
    symbol: "ICICIBANK",
    name: "ICICI Bank",
    price: 987.65,
    change: -8.90,
    changePercent: -0.89,
    high: 1002.00,
    low: 982.50,
    volume: 6789012,
    priceHistory: generatePriceHistory(987.65)
  },
  {
    symbol: "SBIN",
    name: "State Bank of India",
    price: 567.80,
    change: 11.25,
    changePercent: 2.02,
    high: 572.50,
    low: 554.00,
    volume: 9876543,
    priceHistory: generatePriceHistory(567.80)
  }
];

export const updateStockPrice = (stock: Stock): Stock => {
  const volatility = 0.005;
  const randomChange = (Math.random() - 0.5) * 2 * volatility * stock.price;
  const newPrice = Math.max(stock.price + randomChange, stock.price * 0.5);
  const newChange = newPrice - (stock.price - stock.change);
  
  return {
    ...stock,
    price: Number(newPrice.toFixed(2)),
    change: Number(newChange.toFixed(2)),
    changePercent: Number(((newChange / (stock.price - stock.change)) * 100).toFixed(2)),
    high: Math.max(stock.high, newPrice),
    low: Math.min(stock.low, newPrice),
    priceHistory: [...stock.priceHistory.slice(1), Number(newPrice.toFixed(2))]
  };
};
