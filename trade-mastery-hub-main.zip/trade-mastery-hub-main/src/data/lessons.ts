import { Lesson } from "@/types";

export const lessons: Lesson[] = [
  {
    id: "lesson-1",
    title: "What is the Stock Market?",
    description: "Understanding the basics of stock markets and how they work",
    duration: "10 min",
    videoUrl: "https://www.youtube.com/embed/p7HKvqRI_Bo",
    module: "Fundamentals",
    order: 1,
    content: [
      "The stock market is a marketplace where buyers and sellers trade shares of publicly listed companies. Think of it as a giant auction house where millions of people participate every day.",
      "When you buy a stock, you're purchasing a small piece of ownership in a company. If the company does well, the value of your ownership (stock) typically increases.",
      "Stock exchanges like NSE (National Stock Exchange) and BSE (Bombay Stock Exchange) in India, or NYSE in the US, are where these trades happen. They ensure fair and transparent trading.",
      "Prices change based on supply and demand. If more people want to buy a stock than sell it, the price goes up. If more people want to sell, the price goes down."
    ],
    keyTakeaways: [
      "Stocks represent ownership in companies",
      "Stock exchanges facilitate buying and selling",
      "Prices are determined by supply and demand",
      "Anyone can participate through a broker"
    ],
    quiz: [
      {
        id: "q1-1",
        question: "What does buying a stock mean?",
        options: [
          "Lending money to a company",
          "Buying ownership in a company",
          "Getting a guaranteed return",
          "Working for the company"
        ],
        correctAnswer: 1,
        explanation: "When you buy a stock, you become a partial owner of that company, entitled to a share of its profits and growth."
      },
      {
        id: "q1-2",
        question: "What determines stock prices?",
        options: [
          "The government",
          "The company's CEO",
          "Supply and demand",
          "Random selection"
        ],
        correctAnswer: 2,
        explanation: "Stock prices are determined by supply and demand - the balance between how many people want to buy vs sell at any given time."
      },
      {
        id: "q1-3",
        question: "What is a stock exchange?",
        options: [
          "A place to exchange currencies",
          "A marketplace for buying and selling stocks",
          "A bank for companies",
          "A government office"
        ],
        correctAnswer: 1,
        explanation: "Stock exchanges are organized marketplaces where stocks are bought and sold, ensuring fair and transparent trading."
      }
    ]
  },
  {
    id: "lesson-2",
    title: "Understanding Stock Charts",
    description: "Learn to read candlestick charts and identify basic patterns",
    duration: "15 min",
    videoUrl: "https://www.youtube.com/embed/6-1P6e4dz7M",
    module: "Technical Analysis",
    order: 2,
    content: [
      "Stock charts visualize price movements over time. The most common type is the candlestick chart, which shows four key prices: Open, High, Low, and Close (OHLC).",
      "Each candlestick represents a time period (1 minute, 1 day, etc.). A green candle means the price closed higher than it opened. A red candle means it closed lower.",
      "The 'body' of the candle shows the difference between open and close prices. The 'wicks' or 'shadows' show the high and low prices during that period.",
      "Volume bars below the chart show how many shares were traded. High volume often indicates strong conviction behind price movements."
    ],
    keyTakeaways: [
      "Candlesticks show Open, High, Low, Close prices",
      "Green = price went up, Red = price went down",
      "Volume indicates trading activity strength",
      "Patterns can signal potential price movements"
    ],
    quiz: [
      {
        id: "q2-1",
        question: "What does a green candlestick indicate?",
        options: [
          "The stock is environmentally friendly",
          "The price closed higher than it opened",
          "The price closed lower than it opened",
          "High trading volume"
        ],
        correctAnswer: 1,
        explanation: "A green candlestick indicates bullish movement - the closing price was higher than the opening price for that time period."
      },
      {
        id: "q2-2",
        question: "What does OHLC stand for?",
        options: [
          "Only High Level Charts",
          "Open, High, Low, Close",
          "Online Helpful Learning Content",
          "Original Historical Listed Companies"
        ],
        correctAnswer: 1,
        explanation: "OHLC stands for Open, High, Low, and Close - the four key prices shown in each candlestick."
      },
      {
        id: "q2-3",
        question: "What does high trading volume typically indicate?",
        options: [
          "The stock is expensive",
          "Strong conviction behind price movements",
          "The market is closed",
          "The stock is unpopular"
        ],
        correctAnswer: 1,
        explanation: "High volume indicates many traders are participating, which often means there's strong conviction behind the current price trend."
      }
    ]
  },
  {
    id: "lesson-3",
    title: "When to Buy: Entry Strategies",
    description: "Learn how to identify good entry points for trades",
    duration: "12 min",
    videoUrl: "https://www.youtube.com/embed/eVLk9ygz3lI",
    module: "Trading Strategies",
    order: 3,
    content: [
      "Timing your entry is crucial. Buying at the right price can significantly impact your returns. Never buy impulsively - always have a reason.",
      "Support levels are price points where buying pressure typically exceeds selling pressure, causing the price to bounce. These can be good entry points.",
      "Look for confirmation before entering. This could be a bullish candlestick pattern, increasing volume, or positive news about the company.",
      "Consider using limit orders instead of market orders. This lets you specify the exact price you're willing to pay, avoiding overpaying in volatile markets."
    ],
    keyTakeaways: [
      "Never buy without a clear reason",
      "Support levels can be good entry points",
      "Wait for confirmation signals",
      "Use limit orders for better prices"
    ],
    quiz: [
      {
        id: "q3-1",
        question: "What is a support level?",
        options: [
          "The maximum price a stock can reach",
          "A price point where buying pressure exceeds selling",
          "Customer support for traders",
          "The minimum investment required"
        ],
        correctAnswer: 1,
        explanation: "Support levels are price points where historically, buying pressure has exceeded selling pressure, often causing the price to bounce up."
      },
      {
        id: "q3-2",
        question: "What is a limit order?",
        options: [
          "An order with limited quantity",
          "An order that expires quickly",
          "An order specifying the exact price you want",
          "An order for premium stocks only"
        ],
        correctAnswer: 2,
        explanation: "A limit order lets you specify the maximum price you're willing to pay when buying, giving you more control over your entry price."
      },
      {
        id: "q3-3",
        question: "Why is timing your entry important?",
        options: [
          "It doesn't matter when you buy",
          "Better entry prices improve your returns",
          "Stocks only trade at specific times",
          "To avoid paying taxes"
        ],
        correctAnswer: 1,
        explanation: "Buying at better prices directly impacts your profit potential. A good entry can mean the difference between profit and loss."
      }
    ]
  },
  {
    id: "lesson-4",
    title: "When to Sell: Exit Strategies",
    description: "Master the art of taking profits and cutting losses",
    duration: "12 min",
    videoUrl: "https://www.youtube.com/embed/G-EGBqsF4pc",
    module: "Trading Strategies",
    order: 4,
    content: [
      "Knowing when to sell is often harder than knowing when to buy. Have a clear exit plan before you enter any trade.",
      "Set a target price based on technical analysis or fundamental valuation. When reached, take at least partial profits.",
      "More importantly, always set a stop-loss. This is a price at which you'll sell to limit your losses. A common rule is to risk no more than 1-2% of your capital per trade.",
      "Resistance levels are price points where selling pressure typically exceeds buying. These can be good points to take profits."
    ],
    keyTakeaways: [
      "Have an exit plan before entering",
      "Set target prices for taking profits",
      "Always use stop-losses to limit risk",
      "Never risk more than 1-2% per trade"
    ],
    quiz: [
      {
        id: "q4-1",
        question: "What is a stop-loss?",
        options: [
          "A guaranteed profit level",
          "A price at which you sell to limit losses",
          "A type of stock exchange",
          "A trading fee"
        ],
        correctAnswer: 1,
        explanation: "A stop-loss is a predetermined price at which you'll sell a losing position to limit your losses and protect your capital."
      },
      {
        id: "q4-2",
        question: "What's a common risk management rule?",
        options: [
          "Risk 50% per trade for big gains",
          "Never use stop-losses",
          "Risk no more than 1-2% per trade",
          "Always go all-in"
        ],
        correctAnswer: 2,
        explanation: "Risking only 1-2% of your capital per trade ensures that even a series of losses won't devastate your portfolio."
      },
      {
        id: "q4-3",
        question: "What is a resistance level?",
        options: [
          "A price where buying pressure is strong",
          "A price where selling pressure exceeds buying",
          "The stock's minimum price",
          "A type of stock order"
        ],
        correctAnswer: 1,
        explanation: "Resistance levels are prices where historically, selling pressure has exceeded buying pressure, often causing the price to reverse down."
      }
    ]
  },
  {
    id: "lesson-5",
    title: "Risk Management Essentials",
    description: "Protect your capital and trade with discipline",
    duration: "15 min",
    videoUrl: "https://www.youtube.com/embed/fTLCJKPXx0Q",
    module: "Risk Management",
    order: 5,
    content: [
      "Risk management is the most important skill in trading. Professional traders focus more on managing risk than finding profitable trades.",
      "Position sizing determines how much capital to allocate to each trade. Never put all your eggs in one basket.",
      "The risk-reward ratio compares potential profit to potential loss. Aim for trades where potential reward is at least 2x the risk (2:1 ratio).",
      "Emotional control is crucial. Fear and greed are your worst enemies. Stick to your plan and never make impulsive decisions."
    ],
    keyTakeaways: [
      "Risk management > Finding winning trades",
      "Diversify - never go all-in on one stock",
      "Aim for 2:1 risk-reward ratio minimum",
      "Control emotions - stick to your plan"
    ],
    quiz: [
      {
        id: "q5-1",
        question: "What does position sizing mean?",
        options: [
          "The physical size of your computer",
          "How much capital to allocate per trade",
          "The number of stocks you own",
          "Your ranking among traders"
        ],
        correctAnswer: 1,
        explanation: "Position sizing is deciding what percentage of your capital to risk on each trade, crucial for protecting your portfolio."
      },
      {
        id: "q5-2",
        question: "What's a good risk-reward ratio to aim for?",
        options: [
          "1:10 (risk 10 to make 1)",
          "1:1 (risk equals reward)",
          "2:1 (reward is 2x the risk)",
          "It doesn't matter"
        ],
        correctAnswer: 2,
        explanation: "A 2:1 ratio means your potential profit is twice your potential loss. This way, you can be wrong 50% of the time and still be profitable."
      },
      {
        id: "q5-3",
        question: "What are a trader's worst enemies?",
        options: [
          "Other traders",
          "Market makers",
          "Fear and greed",
          "High fees"
        ],
        correctAnswer: 2,
        explanation: "Fear and greed cause impulsive decisions - selling too early out of fear or holding too long out of greed. Emotional discipline is key."
      }
    ]
  }
];

export const getLesson = (id: string): Lesson | undefined => {
  return lessons.find(lesson => lesson.id === id);
};

export const getNextLesson = (currentId: string): Lesson | undefined => {
  const currentIndex = lessons.findIndex(lesson => lesson.id === currentId);
  return lessons[currentIndex + 1];
};
