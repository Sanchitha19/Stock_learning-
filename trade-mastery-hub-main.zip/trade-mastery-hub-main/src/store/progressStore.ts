import { UserProgress } from "@/types";
import { create } from "zustand";
import { persist } from "zustand/middleware";

interface ProgressStore {
  progress: UserProgress;
  completeLesson: (lessonId: string) => void;
  setQuizScore: (lessonId: string, score: number) => void;
  addTimeSpent: (minutes: number) => void;
  unlockTrading: () => void;
  updateBalance: (amount: number) => void;
  addToPortfolio: (symbol: string, name: string, quantity: number, price: number) => void;
  removeFromPortfolio: (symbol: string, quantity: number, price: number) => void;
  addTrade: (trade: UserProgress['tradeHistory'][0]) => void;
  resetProgress: () => void;
}

const initialProgress: UserProgress = {
  completedLessons: [],
  quizScores: {},
  totalTimeSpent: 0,
  tradingUnlocked: false,
  virtualBalance: 100000,
  portfolio: [],
  tradeHistory: []
};

export const useProgressStore = create<ProgressStore>()(
  persist(
    (set, get) => ({
      progress: initialProgress,
      
      completeLesson: (lessonId) => set((state) => ({
        progress: {
          ...state.progress,
          completedLessons: state.progress.completedLessons.includes(lessonId)
            ? state.progress.completedLessons
            : [...state.progress.completedLessons, lessonId]
        }
      })),
      
      setQuizScore: (lessonId, score) => set((state) => ({
        progress: {
          ...state.progress,
          quizScores: { ...state.progress.quizScores, [lessonId]: score }
        }
      })),
      
      addTimeSpent: (minutes) => set((state) => ({
        progress: {
          ...state.progress,
          totalTimeSpent: state.progress.totalTimeSpent + minutes
        }
      })),
      
      unlockTrading: () => set((state) => ({
        progress: { ...state.progress, tradingUnlocked: true }
      })),
      
      updateBalance: (amount) => set((state) => ({
        progress: {
          ...state.progress,
          virtualBalance: state.progress.virtualBalance + amount
        }
      })),
      
      addToPortfolio: (symbol, name, quantity, price) => set((state) => {
        const existing = state.progress.portfolio.find(p => p.symbol === symbol);
        if (existing) {
          const totalQuantity = existing.quantity + quantity;
          const totalCost = (existing.quantity * existing.avgPrice) + (quantity * price);
          const newAvgPrice = totalCost / totalQuantity;
          return {
            progress: {
              ...state.progress,
              portfolio: state.progress.portfolio.map(p =>
                p.symbol === symbol
                  ? { ...p, quantity: totalQuantity, avgPrice: newAvgPrice, currentPrice: price }
                  : p
              )
            }
          };
        }
        return {
          progress: {
            ...state.progress,
            portfolio: [...state.progress.portfolio, { symbol, name, quantity, avgPrice: price, currentPrice: price }]
          }
        };
      }),
      
      removeFromPortfolio: (symbol, quantity, price) => set((state) => {
        const existing = state.progress.portfolio.find(p => p.symbol === symbol);
        if (!existing) return state;
        
        if (existing.quantity <= quantity) {
          return {
            progress: {
              ...state.progress,
              portfolio: state.progress.portfolio.filter(p => p.symbol !== symbol)
            }
          };
        }
        
        return {
          progress: {
            ...state.progress,
            portfolio: state.progress.portfolio.map(p =>
              p.symbol === symbol
                ? { ...p, quantity: p.quantity - quantity, currentPrice: price }
                : p
            )
          }
        };
      }),
      
      addTrade: (trade) => set((state) => ({
        progress: {
          ...state.progress,
          tradeHistory: [trade, ...state.progress.tradeHistory]
        }
      })),
      
      resetProgress: () => set({ progress: initialProgress })
    }),
    {
      name: 'tradetutor-progress'
    }
  )
);
