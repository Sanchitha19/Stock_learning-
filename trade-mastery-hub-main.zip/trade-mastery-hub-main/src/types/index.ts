export interface Lesson {
  id: string;
  title: string;
  description: string;
  duration: string;
  videoUrl: string;
  content: string[];
  keyTakeaways: string[];
  quiz: QuizQuestion[];
  order: number;
  module: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface UserProgress {
  completedLessons: string[];
  quizScores: Record<string, number>;
  totalTimeSpent: number;
  tradingUnlocked: boolean;
  virtualBalance: number;
  portfolio: PortfolioItem[];
  tradeHistory: Trade[];
}

export interface PortfolioItem {
  symbol: string;
  name: string;
  quantity: number;
  avgPrice: number;
  currentPrice: number;
}

export interface Trade {
  id: string;
  symbol: string;
  type: 'BUY' | 'SELL';
  quantity: number;
  price: number;
  timestamp: Date;
  stopLoss?: number;
  targetPrice?: number;
}

export interface Stock {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  high: number;
  low: number;
  volume: number;
  priceHistory: number[];
}
